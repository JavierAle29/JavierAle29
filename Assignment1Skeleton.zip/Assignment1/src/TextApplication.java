public class TextApplication {
	public static final int MAX_NUMBER_OF_STARS = 25;
	private PollList polls;
	
	public TextApplication() {
	}
	
	public TextApplication(PollList polls) {
	}
	
	public void displayPollsBySeat(String[] partyNames) {
	}
	
	public PollList getPolls() {
		return polls;
	}

	public void displayPollDataBySeat(Poll aPoll) {
	}
	
	public void run() {
		
	}
	

	public static void main(String[] args) {
		TextApplication app = new TextApplication(null);
		app.run();
		
	}
}
